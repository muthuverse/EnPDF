﻿using System;
using System.IO;
using PdfExtractor.Engineering;

if (args.Length == 0)
{
    Console.WriteLine("Usage: dotnet run --project pdfextractor-test-runner.csproj -- <pdf-path>");
    return;
}

var pdfPath = args[0];
if (!File.Exists(pdfPath))
{
    Console.WriteLine($"File not found: {pdfPath}");
    return;
}

var extractor = new EngineeringPdfExtractor(pdfPath);
var result = extractor.Extract();
var report = EngineeringDrawingAnalyzer.Format(result);
Console.WriteLine(report);
Console.WriteLine($"PAGE_COUNT={result.PageCount}");
Console.WriteLine($"TEXT_ELEMENTS={result.AllText.Count}");
Console.WriteLine($"IMAGES={result.Images.Count}");
Console.WriteLine($"DIMENSIONS={result.Dimensions.Count}");
Console.WriteLine($"TABLES={result.Tables.Count}");
Console.WriteLine($"NOTES={result.Notes.Count}");
Console.WriteLine($"TOLERANCES={result.Tolerances.Count}");
