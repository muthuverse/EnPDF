﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using PdfExtractor.Engineering;

namespace PdfExtractor.Engineering
{
    /// <summary>
    /// Orchestrates PDF parsing -> decompression -> text extraction -> analysis.
    /// This is the single public API consumers need.
    /// </summary>
    public class EngineeringPdfExtractor
    {
        private readonly PdfParser _parser;

        public EngineeringPdfExtractor(string filePath)
        {
            _parser = new PdfParser(filePath);
        }

        public EngineeringExtractionResult Extract()
        {
            var allText = new List<TextElement>();
            var images = new List<(byte[], string)>();
            var metadata = new Dictionary<string, string>();

            // Metadata comes from trailer /Info, not from catalog /Root.
            int infoId = _parser.GetInfoObjectId();
            if (infoId > 0)
            {
                var info = _parser.GetObject(infoId);
                if (info != null)
                    foreach (var kv in info.Dict)
                        metadata[kv.Key] = kv.Value.Trim('(', ')');
            }

            // Page-by-page extraction
            var pageIds = _parser.GetPageObjectIds();

            for (int pageNum = 0; pageNum < pageIds.Count; pageNum++)
            {
                int pageId = pageIds[pageNum];
                var page = _parser.GetObject(pageId);
                if (page == null) continue;

                // Text: iterate through /Contents streams
                string contentsVal = page.Get("/Contents");
                foreach (int contentId in ParseRefs(contentsVal))
                {
                    var contentObj = _parser.GetObject(contentId);
                    if (contentObj?.RawStream == null) continue;

                    byte[] raw = PdfStream.Decompress(
                        contentObj.RawStream, contentObj.Get("/Filter"));

                    var elems = PdfStream.ExtractTextElements(raw, pageNum + 1);
                    allText.AddRange(elems);
                }

                // Images: traverse /Resources -> /XObject
                ExtractImages(page, images);
            }

            // Engineering analysis
            var analyzer = new EngineeringDrawingAnalyzer();
            return analyzer.Analyze(allText, images, metadata, pageIds.Count);
        }

        private void ExtractImages(PdfObject page, List<(byte[], string)> images)
        {
            string resVal = page.Get("/Resources");
            PdfObject resources = null;

            if (!string.IsNullOrEmpty(resVal))
            {
                if (resVal.TrimStart().StartsWith("<<"))
                {
                    resources = new PdfObject();
                    PdfParser.ParseDictionaryInto(resources.Dict, resVal);
                }
                else
                {
                    int resId = ParseRef(resVal);
                    if (resId > 0) resources = _parser.GetObject(resId);
                }
            }

            if (resources == null) return;

            string xobjVal = resources.Get("/XObject");
            if (string.IsNullOrEmpty(xobjVal)) return;

            var xobjDict = new Dictionary<string, string>();
            if (xobjVal.TrimStart().StartsWith("<<"))
                PdfParser.ParseDictionaryInto(xobjDict, xobjVal);
            else
            {
                int xobjId = ParseRef(xobjVal);
                if (xobjId > 0)
                {
                    var xobj = _parser.GetObject(xobjId);
                    if (xobj != null) xobjDict = xobj.Dict;
                }
            }

            foreach (var kv in xobjDict)
            {
                int imgId = ParseRef(kv.Value);
                if (imgId <= 0) continue;

                var imgObj = _parser.GetObject(imgId);
                if (imgObj?.RawStream == null) continue;
                if (imgObj.Get("/Subtype") != "/Image") continue;

                string filter = imgObj.Get("/Filter") ?? "";
                string format = DetectImageFormat(filter, imgObj.RawStream);

                // For image formats that are already natively encoded (JPEG/JP2),
                // return raw stream. For others, try decompression.
                byte[] imgData = filter.Contains("/DCTDecode") || filter.Contains("/JPXDecode")
                    ? imgObj.RawStream
                    : PdfStream.Decompress(imgObj.RawStream, filter);

                images.Add((imgData, format));
            }
        }

        private static string DetectImageFormat(string filter, byte[] data)
        {
            if (filter.Contains("/DCTDecode")) return "jpg";
            if (filter.Contains("/JPXDecode")) return "jp2";
            if (filter.Contains("/JBIG2Decode")) return "jbig2";

            // Magic bytes
            if (data.Length >= 4 &&
                data[0] == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G')
                return "png";
            if (data.Length >= 2 && data[0] == 0xFF && data[1] == 0xD8)
                return "jpg";

            return "bin";
        }

        private static int ParseRef(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            var m = Regex.Match(s, @"(\d+)\s+\d+\s+R");
            return m.Success ? int.Parse(m.Groups[1].Value) : 0;
        }

        private static List<int> ParseRefs(string s)
        {
            var ids = new List<int>();
            if (string.IsNullOrEmpty(s)) return ids;

            if (s.TrimStart().StartsWith("["))
            {
                foreach (Match m in Regex.Matches(s, @"(\d+)\s+\d+\s+R"))
                    ids.Add(int.Parse(m.Groups[1].Value));
            }
            else
            {
                int id = ParseRef(s);
                if (id > 0) ids.Add(id);
            }
            return ids;
        }
    }
}

class Program
{
    [System.STAThread]
    static void Main(string[] args)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        System.Windows.Forms.Application.EnableVisualStyles();
        System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
        System.Windows.Forms.Application.Run(new ExtractorForm());
    }
}

internal sealed class ExtractorForm : System.Windows.Forms.Form
{
    private readonly System.Windows.Forms.TextBox _pathBox;
    private readonly System.Windows.Forms.CheckBox _saveImagesBox;
    private readonly System.Windows.Forms.Button _browseButton;
    private readonly System.Windows.Forms.Button _extractButton;
    private readonly System.Windows.Forms.TextBox _outputBox;
    private readonly System.Windows.Forms.Label _statusLabel;

    public ExtractorForm()
    {
        Text = "Engineering PDF Extractor";
        Width = 400;
        Height = 220;
        StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

        var topPanel = new System.Windows.Forms.Panel
        {
            Dock = System.Windows.Forms.DockStyle.Top,
            Height = 84
        };

        _pathBox = new System.Windows.Forms.TextBox
        {
            Left = 12,
            Top = 12,
            Width = 80,
            Anchor = System.Windows.Forms.AnchorStyles.Top |
                     System.Windows.Forms.AnchorStyles.Left |
                     System.Windows.Forms.AnchorStyles.Right
        };

        _browseButton = new System.Windows.Forms.Button
        {
            Text = "Browse PDF",
            Left = 100,
            Top = 10,
            Width = 94,
            Height = 28,
            Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right
        };
        _browseButton.Click += (_, _) => BrowsePdf();

        _extractButton = new System.Windows.Forms.Button
        {
            Text = "Extract",
            Left = 25,
            Top = 45,
            Width = 94,
            Height = 28,
            Anchor = System.Windows.Forms.AnchorStyles.None | System.Windows.Forms.AnchorStyles.Right
        };
        _extractButton.Click += (_, _) => RunExtraction();

        _saveImagesBox = new System.Windows.Forms.CheckBox
        {
            Text = "Save extracted images",
            Left = 12,
            Top = 46,
            Width = 180,
            Checked = true
        };

        _statusLabel = new System.Windows.Forms.Label
        {
            Left = 210,
            Top = 48,
            Width = 760,
            Height = 24,
            Anchor = System.Windows.Forms.AnchorStyles.Top |
                     System.Windows.Forms.AnchorStyles.Left |
                     System.Windows.Forms.AnchorStyles.Right,
            Text = "Select a PDF and click Extract."
        };

        _outputBox = new System.Windows.Forms.TextBox
        {
            Dock = System.Windows.Forms.DockStyle.Fill,
            Multiline = true,
            ScrollBars = System.Windows.Forms.ScrollBars.Both,
            ReadOnly = true,
            Font = new System.Drawing.Font("Consolas", 9f),
            WordWrap = false
        };

        topPanel.Controls.Add(_pathBox);
        topPanel.Controls.Add(_browseButton);
        topPanel.Controls.Add(_extractButton);
        topPanel.Controls.Add(_saveImagesBox);
        topPanel.Controls.Add(_statusLabel);

        Controls.Add(_outputBox);
        Controls.Add(topPanel);
    }

    private void BrowsePdf()
    {
        using var dialog = new System.Windows.Forms.OpenFileDialog
        {
            Title = "Select Engineering Drawing PDF",
            Filter = "PDF Files (*.pdf)|*.pdf|All Files (*.*)|*.*",
            FilterIndex = 1,
            Multiselect = false,
            CheckFileExists = true,
            CheckPathExists = true,
            RestoreDirectory = true,
        };

        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            _pathBox.Text = dialog.FileName;
    }

    private void RunExtraction()
    {
        string filePath = _pathBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(filePath))
        {
            System.Windows.Forms.MessageBox.Show(
                "Please select a PDF first.",
                "Missing file",
                System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Warning);
            return;
        }

        if (!File.Exists(filePath))
        {
            System.Windows.Forms.MessageBox.Show(
                $"File not found:\n{filePath}",
                "Invalid file path",
                System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Error);
            return;
        }

        try
        {
            ToggleBusy(true, "Extracting...");
            _outputBox.Text = "";

            var extractor = new PdfExtractor.Engineering.EngineeringPdfExtractor(filePath);
            var result = extractor.Extract();

            string report = EngineeringDrawingAnalyzer.Format(result);
            _outputBox.Text = report;

            string outPath = Path.ChangeExtension(filePath, ".extraction.txt");
            File.WriteAllText(outPath, report, Encoding.UTF8);

            string imageMessage = "";
            if (_saveImagesBox.Checked && result.Images.Count > 0)
            {
                string imageDir = Path.Combine(
                    Path.GetDirectoryName(filePath) ?? ".",
                    Path.GetFileNameWithoutExtension(filePath) + "_images");

                Directory.CreateDirectory(imageDir);
                for (int i = 0; i < result.Images.Count; i++)
                {
                    string imgPath = Path.Combine(
                        imageDir,
                        $"image_{i:D3}.{result.Images[i].Format}");
                    File.WriteAllBytes(imgPath, result.Images[i].Data);
                }

                imageMessage = $"\nImages saved to:\n{imageDir}";
            }

            ToggleBusy(false, "Extraction complete.");
            System.Windows.Forms.MessageBox.Show(
                $"Extraction complete.\n\nReport saved to:\n{outPath}{imageMessage}",
                "Done",
                System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            ToggleBusy(false, "Extraction failed.");
            System.Windows.Forms.MessageBox.Show(
                $"Error:\n{ex.Message}",
                "Extraction error",
                System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Error);
            _outputBox.Text = ex.ToString();
        }
    }

    private void ToggleBusy(bool busy, string status)
    {
        _browseButton.Enabled = !busy;
        _extractButton.Enabled = !busy;
        _pathBox.Enabled = !busy;
        _saveImagesBox.Enabled = !busy;
        _statusLabel.Text = status;
        Cursor = busy ? System.Windows.Forms.Cursors.WaitCursor : System.Windows.Forms.Cursors.Default;
        System.Windows.Forms.Application.DoEvents();
    }
}
